//
//  main.cpp
//  Calendar
//
//  Created by Daniel Shterev on 20.04.20.
//  Copyright © 2020 Daniel Shterev. All rights reserved.
//

#include <iostream>
#include "Calendar.hpp"

int main()
{
    Calendar calendar ;
    calendar.startProgram();
    return 0 ;
}
